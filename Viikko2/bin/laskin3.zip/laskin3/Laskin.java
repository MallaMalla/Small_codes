package laskin3;

public class Laskin 
{
	protected double luku1;
	protected double luku2;
	protected double luku3;
	protected double summa;
	
	
		public void setLuku1(double newLuku1)
		{
			luku1 = newLuku1;
		}
	
		public double getLuku1()
		{
			return luku1;
		}
	
		public void setLuku2(double newLuku2)
		{
			luku2 = newLuku2;
		}
	
		public double getLuku2()
		{
			return luku2;
		}
		
		public void setLuku3(double newLuku3)
		{
			luku3 = newLuku3;
		}
	
		public double getLuku3()
		{
			return luku3;
		}
		
		public void setSumma(double newSumma)
		{
			summa = newSumma;
		}
	
		public double getSumma()
		{
			return summa;
		}
}
